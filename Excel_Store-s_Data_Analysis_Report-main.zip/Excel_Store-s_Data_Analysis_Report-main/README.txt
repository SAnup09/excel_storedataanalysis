                                         Store's Data Analysis using Excel


                     Excited to share my latest Excel project: a sales dashboard that provides insights into order wise sales amount, gender wise sales, order status, top 5 states, age group wise and gender wise sales, and e-commerce wise sales.

This dashboard is interactive and visually appealing, making it easy to read and understand the data. It is also comprehensive, providing insights into a variety of sales data that can be used to make informed decisions about sales and marketing strategies.

I am proud to have created this tool, which will help my colleagues to improve sales performance and make better business decisions.

You can also include a relevant hashtag, such as #data, #datascience, or #analytics, to help people find your post.

Here is another option:
New Excel dashboard for sales analysis!

This dashboard provides insights into order wise sales amount, gender wise sales, order status, top 5 states, age group wise and gender wise sales, and e-commerce wise sales. It is interactive and visually appealing, making it easy to read and understand the data.

This dashboard is a valuable tool for sales and marketing professionals who want to improve sales performance and make better business decisions.


Sample Insights:
1. Women are more likely to buy compared to men(~65%)
2. Maharashtra, Karnataka and Uttar Pradesh are the Top 3
3. Adult age group (30-49 yrs) is max contributing (~50%)
4. Amazon, Flipkart and Myntra channels are max contributing(~80%)




Final Conclusion to improve store sales:
Target women customers of age group (30-49 yrs) living in Maharashtra, Karnataka and Uttar Pradesh by showing ads/offers/coupons available on Amazon, Flipkart and Myntra
